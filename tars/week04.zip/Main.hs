main = do
  putStrLn "Hello"
  putStrLn "World"


--  OUTLINE

-- 1 High Order Functions
-- -- 1.1 Map
-- -- 1.2 Filter
-- -- 1.3 Foldr Foldl  - accumulator patter applied left to right - right to left
-- -- 1.4 Application
-- -- 1.5 Composition