main = do
  putStrLn "Hello"
  putStrLn "World"
