a :: Int
a = 7
b :: Float
b = 2.6

