main = do
  putStr "Hello "
  putStrLn "World"
  var<-getChar
  putChar var