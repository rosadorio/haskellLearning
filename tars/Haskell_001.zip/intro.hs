module Intromodule where

x = 10

f :: (Num a) => a -> a -> a
f x y = y*( x + 1)

a :: Integer
a = 12




